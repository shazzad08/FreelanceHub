# FreelancePro — Full Stack Django Platform
### Complete Build Guide & Milestones (Beginner-Friendly)

---

## 🗂️ Project Structure

```
freelancer_platform/          ← Root folder (run commands here)
│
├── manage.py                 ← Django's main command tool
├── requirements.txt          ← All Python packages needed
├── db.sqlite3                ← Database (auto-created)
│
├── freelancer_platform/      ← Main Django config app
│   ├── settings.py           ← All project settings
│   ├── urls.py               ← Root URL routes
│   └── wsgi.py
│
├── accounts/                 ← User auth, profiles
│   ├── models.py             ← Custom User model
│   ├── views.py              ← Register, login, profile
│   ├── forms.py              ← Registration, login, edit forms
│   ├── urls.py               ← /accounts/* routes
│   └── admin.py
│
├── projects/                 ← Project listings
│   ├── models.py             ← Project, Category models
│   ├── views.py              ← List, detail, post, edit
│   ├── forms.py              ← Post project, filter forms
│   ├── urls.py               ← / and /projects/* routes
│   ├── admin.py
│   └── management/commands/seed_data.py  ← Demo data
│
├── proposals/                ← Freelancer applications
│   ├── models.py             ← Proposal model
│   ├── views.py              ← Submit, update status
│   ├── forms.py
│   └── urls.py
│
├── reviews/                  ← Client reviews of freelancers
│   ├── models.py             ← Review model
│   ├── views.py
│   └── urls.py
│
├── templates/                ← All HTML files
│   ├── base.html             ← Shared layout (navbar, footer)
│   ├── accounts/
│   ├── projects/
│   ├── proposals/
│   ├── reviews/
│   └── emails/
│
└── static/                   ← CSS, JS, images
```

---

## ⚡ Quick Start (Run the project in 5 steps)

### Step 1 — Create a Virtual Environment
```bash
# In your terminal, navigate to the project folder
cd freelancer_platform

# Create a virtual environment (keeps packages isolated)
python -m venv venv

# Activate it:
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate
```

### Step 2 — Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3 — Set Up the Database
```bash
# This creates all the database tables
python manage.py makemigrations
python manage.py migrate
```

### Step 4 — Create Admin User + Seed Demo Data
```bash
# Create a superuser (for /admin panel)
python manage.py createsuperuser

# Load demo categories, users, and projects
python manage.py seed_data
```

### Step 5 — Run the Server
```bash
python manage.py runserver
```

Open: **http://127.0.0.1:8000**

**Demo Login Credentials** (created by seed_data):
- Client: `client_demo` / `demo1234`
- Freelancer: `freelancer_demo` / `demo1234`

---

## 📋 Milestones — How to Learn As You Build

---

### 🎯 MILESTONE 1 — User Authentication (Week 1)
**Goal:** Users can register, verify email, login, and logout.

**What you'll learn:**
- Django's built-in auth system
- Custom User models (AbstractUser)
- Sessions and cookies
- Sending emails

**Key files to study:**
- `accounts/models.py` → See how we extend Django's User model
- `accounts/views.py` → Follow the `register_view` step by step
- `accounts/forms.py` → How forms validate data

**How it works — Registration Flow:**
```
User fills form → form.is_valid() → save user (is_email_verified=False)
→ send_verification_email() → user clicks link → verify_email_view()
→ is_email_verified=True → user can now login
```

**Try this yourself:**
1. Register at `/accounts/register/`
2. Check your terminal — the verification email prints there (console backend)
3. Copy the verification URL from the terminal and open it
4. Now login at `/accounts/login/`

**For production email** (change in settings.py):
```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'yourgmail@gmail.com'
EMAIL_HOST_PASSWORD = 'your-app-password'  # Gmail App Password
```

---

### 🎯 MILESTONE 2 — Project Listings & Filtering (Week 2)
**Goal:** Browse, search, sort, and filter projects.

**What you'll learn:**
- Django ORM queries (filter, exclude, order_by)
- GET parameters for filtering
- Template tags (for loops, if statements)

**Key files to study:**
- `projects/models.py` → Project and Category models
- `projects/views.py` → `project_list_view` (the filtering logic)
- `templates/projects/project_list.html` → The filter form

**How filtering works:**
```python
# When user submits filter form, GET params are added to URL:
# /?search=django&category=1&sort_by=-budget

projects = Project.objects.filter(status='open')  # Start with all open projects

if search:
    projects = projects.filter(
        Q(title__icontains=search) | Q(description__icontains=search)
    )
# Q() allows OR conditions; icontains = case-insensitive search

if category:
    projects = projects.filter(category=category)

projects = projects.order_by(sort_by)  # e.g. '-budget' = high to low
```

**Try this yourself:**
1. Go to `/admin/` → add some Categories (Web Dev, Design, Writing)
2. Run `python manage.py seed_data` for instant sample data
3. Try the filters on the homepage

---

### 🎯 MILESTONE 3 — Project Details (Week 2-3)
**Goal:** Show full project info including client details and attachments.

**What you'll learn:**
- ForeignKey relationships
- Template context variables
- File uploads (attachments)

**Key files to study:**
- `projects/views.py` → `project_detail_view`
- `templates/projects/project_detail.html`

**How ForeignKey works:**
```python
# In models.py:
class Project(models.Model):
    client = models.ForeignKey(User, on_delete=models.CASCADE)

# In templates, you access related data with dot notation:
{{ project.client.username }}        # The client's username
{{ project.client.get_full_name }}   # Their full name
{{ project.client.location }}        # Their location
```

---

### 🎯 MILESTONE 4 — Proposals System (Week 3)
**Goal:** Freelancers can apply to projects; clients can accept/reject.

**What you'll learn:**
- Many-to-one relationships
- Login-required views
- Business logic in views

**Key files:**
- `proposals/models.py` → Proposal model
- `proposals/views.py` → submit_proposal_view

**How the proposal flow works:**
```
Freelancer visits project → sees Apply form → submits cover letter + bid
→ Proposal saved (status='pending') → Client sees all proposals
→ Client clicks Accept → proposal.status='accepted', project.status='in_progress'
```

**The unique_together constraint prevents duplicate proposals:**
```python
class Meta:
    unique_together = ['project', 'freelancer']
# This means one freelancer can only submit ONE proposal per project
```

---

### 🎯 MILESTONE 5 — Reviews & Ratings (Week 4)
**Goal:** Clients can rate and review freelancers after completion.

**What you'll learn:**
- Data validation (1-5 stars)
- Aggregation (calculating averages)

**How ratings display on profiles:**
```python
# In User model (accounts/models.py):
def get_average_rating(self):
    reviews = Review.objects.filter(freelancer=self)
    if reviews.exists():
        total = sum(r.rating for r in reviews)
        return round(total / reviews.count(), 1)
    return None
```

---

### 🎯 MILESTONE 6 — Deployment (Week 4-5)
**Goal:** Put your project live on the internet.

**Recommended: Deploy to Railway (free + easy)**

```bash
# Step 1: Add these packages
pip install gunicorn whitenoise psycopg2-binary
pip freeze > requirements.txt

# Step 2: Create Procfile (in root folder)
echo "web: gunicorn freelancer_platform.wsgi" > Procfile

# Step 3: Update settings.py for production
ALLOWED_HOSTS = ['your-app.railway.app']
DEBUG = False
STATIC_ROOT = BASE_DIR / 'staticfiles'

# Add WhiteNoise to MIDDLEWARE (for serving static files):
MIDDLEWARE = [
    'whitenoise.middleware.WhiteNoiseMiddleware',  # ← Add this
    ...
]

# Step 4: Push to GitHub, then connect Railway to your repo
# Railway auto-detects Django and deploys!
```

**Alternative: Render.com** (also free)
- Create account at render.com
- New → Web Service → Connect GitHub repo
- Build Command: `pip install -r requirements.txt && python manage.py migrate`
- Start Command: `gunicorn freelancer_platform.wsgi`

---

## 🔑 Key Django Concepts in This Project

### 1. Models = Database Tables
```python
class Project(models.Model):
    title = models.CharField(max_length=200)   # Text column, max 200 chars
    budget = models.DecimalField(...)           # Decimal number column
    client = models.ForeignKey(User, ...)       # Links to User table
```

### 2. Views = Python Functions That Handle Requests
```python
def my_view(request):
    data = SomeModel.objects.all()          # Get data from DB
    return render(request, 'template.html', {'data': data})  # Send to template
```

### 3. URLs = Routes That Map to Views
```python
urlpatterns = [
    path('projects/', views.project_list_view, name='project_list'),
    path('projects/<int:pk>/', views.project_detail_view, name='project_detail'),
#                   ↑ <int:pk> captures the number from the URL (e.g. /projects/5/)
]
```

### 4. Templates = HTML with Django Tags
```html
{% for project in projects %}         {# Loop over data #}
  {{ project.title }}                  {# Display variable #}
  {% if user.is_authenticated %}       {# Conditional #}
    <a href="{% url 'projects:project_detail' project.pk %}">View</a>
  {% endif %}
{% endfor %}
```

### 5. Forms = Validate User Input
```python
class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'budget', 'deadline']
# ModelForm auto-creates form fields from the model
```

---

## 🔧 Common Commands

```bash
# After editing models, always run:
python manage.py makemigrations
python manage.py migrate

# Create superuser for admin panel
python manage.py createsuperuser

# Seed sample data
python manage.py seed_data

# Collect static files (for production)
python manage.py collectstatic

# Django shell (test queries interactively)
python manage.py shell
```

---

## 🐛 Troubleshooting Common Errors

| Error | Fix |
|-------|-----|
| `ModuleNotFoundError: No module named 'crispy_forms'` | Run `pip install django-crispy-forms crispy-bootstrap5` |
| `TemplateDoesNotExist` | Check `TEMPLATES['DIRS']` in settings.py includes `BASE_DIR / 'templates'` |
| `No such table: accounts_user` | Run `python manage.py migrate` |
| `UNIQUE constraint failed` | User tried to submit duplicate proposal — handled by unique_together |
| Static files not loading | Run `python manage.py collectstatic` and check STATICFILES_DIRS |
| Email not sending | In dev, check terminal output — email prints to console by default |

---

## ✅ Features Checklist

- [x] User Registration with email + password
- [x] Email Verification (token-based)
- [x] Login / Logout
- [x] Only verified users can login
- [x] Project Listings with title, description, budget, deadline
- [x] Sort by budget (low-high, high-low)
- [x] Filter by category
- [x] Search projects
- [x] Project Details page with client info + attachments
- [x] Freelancer Reviews & Ratings (1-5 stars)
- [x] Proposal submission (cover letter + bid + days)
- [x] Applied job history on profile page
- [x] Client can accept/reject proposals
- [x] User Profile page
- [x] Responsive design (Bootstrap 5)
- [ ] Deployment (do this as your final milestone)

---

## 💡 Resume Tips

When describing this project on your resume, write:

**FreelancePro — Full Stack Web Application** | Django, Python, Bootstrap 5, SQLite
- Architected a multi-role platform (clients & freelancers) with custom user model, JWT-style email verification, and role-based access control
- Implemented a real-time project marketplace with dynamic filtering, sorting, and search using Django ORM's Q objects
- Built a proposal management system with status workflows (pending → accepted/rejected) and applied job history tracking
- Designed relational data models with ForeignKey and Many-to-One relationships across 5 Django apps
- Deployed to [Railway/Render] with WhiteNoise static file serving and environment-based configuration

---

*Built with ❤️ using Django 4.2 + Bootstrap 5*
